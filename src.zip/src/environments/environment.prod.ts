export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyAeswPszZdevD86Vy9G4lROL3GUxRnRpZY',
    authDomain: 'football-worldcup-2018-d85c3.firebaseapp.com',
    databaseURL:"https://football-worldcup-2018-d85c3.firebaseio.com",
    projectId: 'football-worldcup-2018-d85c3',
    storageBucket: 'football-worldcup-2018-d85c3.appspot.com',
    messagingSenderId: '585983855098'
  }
};
